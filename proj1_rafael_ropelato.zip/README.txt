The program can be used very simle.

First run the cell with the import and the function definitions.

After that, enter the desired start and goal state in the third cell (as 3x3 list). The output will provide all steps with directions in the end. 